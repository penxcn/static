<?php

if (!defined('ABSPATH'))
    exit;

function zic_settings_page()
{
    // 1. 数据获取逻辑
    $post_types = get_post_types(['public' => true], 'objects');
    $enabled_types = get_option('zic_enabled_post_types');
    if (!$enabled_types || !is_array($enabled_types)) {
        $enabled_types = array('post', 'page');
    }
    $delete_featured = get_option('zic_delete_featured', '1');
    $enable_log = get_option('zic_enable_log', '1');
    $exclude_keywords = get_option('zic_exclude_keywords', '');

    // 2. 表单处理逻辑
    if (isset($_POST['zic_clear_log']) && check_admin_referer('zic_save_settings')) {
        $log_file = WP_CONTENT_DIR . '/debug.log';
        if (file_exists($log_file)) {
            file_put_contents($log_file, '');
            echo '<div class="notice notice-success is-dismissible"><p>日志已清空。</p></div>';
        }
    }

    if (isset($_POST['zic_save_settings']) && check_admin_referer('zic_save_settings')) {
        $selected = isset($_POST['zic_post_types']) ? array_map('sanitize_text_field', $_POST['zic_post_types']) : [];
        update_option('zic_enabled_post_types', $selected);
        update_option('zic_delete_featured', isset($_POST['zic_delete_featured']) ? '1' : '0');
        update_option('zic_enable_log', isset($_POST['zic_enable_log']) ? '1' : '0');
        update_option('zic_exclude_keywords', sanitize_text_field($_POST['zic_exclude_keywords'] ?? ''));
        echo '<div class="notice notice-success is-dismissible"><p>设置已保存。</p></div>';

        $enabled_types = $selected;
        $delete_featured = isset($_POST['zic_delete_featured']) ? '1' : '0';
        $enable_log = isset($_POST['zic_enable_log']) ? '1' : '0';
        $exclude_keywords = sanitize_text_field($_POST['zic_exclude_keywords'] ?? '');
    }
    ?>

    <style>
        /* ================== 基础样式 ================== */
        .zic-wrap {
            max-width: 1400px;
            margin: 20px 20px 0 0;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            color: #334155;
        }

        /* 头部样式 */
        .zic-header {
            background: #fff;
            padding: 24px 32px;
            border-radius: 12px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border: 1px solid #f1f5f9;
        }

        .zic-header h1 {
            margin: 0;
            font-size: 26px;
            color: #0f172a;
            font-weight: 700;
        }

        .zic-header p {
            margin: 6px 0 0;
            color: #64748b;
            font-size: 15px;
        }

        /* 导航 Tab */
        .zic-nav {
            margin-bottom: 24px;
            border-bottom: 2px solid #e2e8f0;
            display: flex;
            gap: 32px;
            overflow-x: auto;
            white-space: nowrap;
            -webkit-overflow-scrolling: touch;
        }

        .zic-nav::-webkit-scrollbar {
            display: none;
        }

        /* 隐藏导航条滚动条 */

        .zic-nav a {
            text-decoration: none;
            color: #64748b;
            font-weight: 600;
            padding-bottom: 14px;
            margin-bottom: -2px;
            border-bottom: 2px solid transparent;
            transition: all 0.2s;
            font-size: 15px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
            flex-shrink: 0;
        }

        .zic-nav a:hover,
        .zic-nav a.active {
            color: #2563eb;
        }

        .zic-nav a.active {
            border-bottom-color: #2563eb;
        }

        .zic-nav-icon {
            font-size: 18px;
        }

        /* 内容面板 */
        .zic-tab-panel {
            display: none;
            animation: fadeIn 0.3s ease;
        }

        .zic-tab-panel.active {
            display: block;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(5px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* 卡片样式 */
        .zic-card {
            background: #fff;
            border-radius: 12px;
            border: 1px solid #e2e8f0;
            padding: 28px;
            margin-bottom: 24px;
        }

        .zic-card-title {
            font-size: 18px;
            font-weight: 700;
            margin: 0 0 24px;
            padding-bottom: 16px;
            border-bottom: 1px solid #f1f5f9;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        /* 按钮样式 */
        .zic-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 14px;
            line-height: 1.5;
            cursor: pointer;
            transition: all 0.2s;
            border: 1px solid transparent;
            text-decoration: none;
            gap: 6px;
        }

        .zic-btn:active {
            transform: translateY(1px);
        }

        .zic-btn-primary {
            background-color: #2563eb;
            color: #fff;
            border-color: #2563eb;
        }

        .zic-btn-primary:hover {
            background-color: #1d4ed8;
            color: #fff;
        }

        .zic-btn-danger {
            background-color: #ef4444;
            color: #fff;
            border-color: #ef4444;
        }

        .zic-btn-danger:hover {
            background-color: #dc2626;
            color: #fff;
        }

        .zic-btn-secondary {
            background-color: #fff;
            color: #475569;
            border-color: #cbd5e1;
        }

        .zic-btn-secondary:hover {
            background-color: #f8fafc;
            color: #0f172a;
        }

        .zic-btn-sm {
            padding: 6px 12px;
            font-size: 12px;
            border-radius: 6px;
        }

        .zic-btn-ghost-danger {
            background-color: #fef2f2;
            color: #ef4444;
            border-color: #fecaca;
        }

        .zic-btn-ghost-danger:hover {
            background-color: #ef4444;
            color: #fff;
            border-color: #ef4444;
        }

        .zic-btn-lg {
            padding: 12px 24px;
            font-size: 15px;
        }

        .zic-wrap .button {
            border: none;
            background: none;
            box-shadow: none;
            padding: 0;
        }

        /* 表单 */
        .zic-form-group {
            margin-bottom: 24px;
        }

        .zic-form-label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: #334155;
            font-size: 14px;
        }

        .zic-input-text {
            width: 100%;
            max-width: 500px;
            padding: 10px 14px;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            font-size: 14px;
        }

        .zic-checkbox-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 12px;
        }

        .zic-checkbox-label {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.2s;
        }

        .zic-checkbox-label input {
            margin-right: 10px;
            accent-color: #2563eb;
        }

        /* 扫描过滤区 */
        .zic-filter-grid {
            display: flex;
            gap: 24px;
            margin-bottom: 24px;
        }

        .zic-filter-box {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            padding: 20px;
            border-radius: 8px;
            flex: 1;
        }

        .zic-filter-box h4 {
            margin: 0 0 12px;
            font-size: 13px;
            color: #64748b;
            text-transform: uppercase;
            font-weight: 700;
        }

        /* 操作栏 */
        .zic-action-bar {
            display: flex;
            align-items: center;
            gap: 20px;
            padding: 24px;
            background: #eff6ff;
            border: 1px solid #bfdbfe;
            border-radius: 12px;
            margin-top: 24px;
        }

        /* 统计卡片 */
        .zic-stats-row {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 24px;
        }

        .zic-stat-card {
            background: #fff;
            border: 1px solid #e2e8f0;
            padding: 20px;
            border-radius: 12px;
            text-align: center;
        }

        .zic-stat-value {
            font-size: 28px;
            font-weight: 800;
            color: #0f172a;
            display: block;
            line-height: 1.2;
        }

        .zic-stat-label {
            font-size: 12px;
            color: #64748b;
            text-transform: uppercase;
            margin-top: 5px;
            font-weight: 600;
        }

        .zic-stat-card.highlight {
            background: #f0fdf4;
            border-color: #bbf7d0;
        }

        .zic-stat-card.highlight .zic-stat-value {
            color: #15803d;
        }

        /* 表格样式 */
        .zic-table-container {
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            overflow: hidden;
            margin-top: 24px;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .zic-table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            min-width: 900px;
        }

        .zic-table th {
            background: #f8fafc;
            color: #475569;
            font-weight: 600;
            padding: 14px 20px;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
            white-space: nowrap;
            font-size: 13px;
        }

        .zic-table td {
            padding: 14px 20px;
            border-bottom: 1px solid #f1f5f9;
            vertical-align: middle;
            color: #334155;
            font-size: 14px;
        }

        .zic-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 99px;
            font-size: 11px;
            font-weight: 700;
            line-height: 1;
        }

        .zic-badge-unused {
            background: #dcfce7;
            color: #166534;
        }

        .zic-badge-ghost {
            background: #fee2e2;
            color: #991b1b;
        }

        .zic-badge-referenced {
            background: #e0f2fe;
            color: #075985;
        }

        /* 日志区域优化 */
        .zic-log-container {
            background: #0f172a;
            border-radius: 12px;
            color: #e2e8f0;
            font-family: monospace;
            overflow: hidden;
            border: 1px solid #334155;
        }

        .zic-log-header {
            padding: 12px 20px;
            background: #1e293b;
            border-bottom: 1px solid #334155;
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            font-weight: 600;
            color: #94a3b8;
        }

        .zic-log-body {
            padding: 20px;
            max-height: 500px;
            overflow-y: auto;
            font-size: 12px;
            line-height: 1.7;
            white-space: pre-wrap;
            /* 允许换行，如需强制不换行可改为 pre */

            /* Firefox 细滚动条 */
            scrollbar-width: thin;
            scrollbar-color: #334155 #0f172a;
        }

        /* WebKit 细滚动条优化 (Chrome, Safari, Edge) */
        .zic-log-body::-webkit-scrollbar {
            width: 6px;
            /* 纵向滚动条宽度 */
            height: 6px;
            /* 横向滚动条高度 */
        }

        .zic-log-body::-webkit-scrollbar-track {
            background: #0f172a;
            /* 轨道背景色 (与日志背景一致) */
            border-radius: 3px;
        }

        .zic-log-body::-webkit-scrollbar-thumb {
            background: #334155;
            /* 滑块颜色 */
            border-radius: 3px;
        }

        .zic-log-body::-webkit-scrollbar-thumb:hover {
            background: #475569;
            /* 悬停时滑块变亮 */
        }

        .zic-log-body::-webkit-scrollbar-corner {
            background: #0f172a;
            /* 两个滚动条交汇处背景 */
        }

        /* 移动端自适应 */
        @media (max-width: 782px) {
            .zic-wrap {
                margin: 10px 10px 0 0;
            }

            .zic-header {
                padding: 20px;
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }

            .zic-header>div:last-child {
                width: 100%;
            }

            .zic-header .zic-btn {
                width: 100%;
            }

            .zic-stats-row {
                grid-template-columns: repeat(2, 1fr);
            }

            .zic-filter-grid {
                flex-direction: column;
                gap: 15px;
            }

            .zic-action-bar {
                flex-direction: column;
                align-items: stretch;
                text-align: center;
            }

            #zic-scan-status {
                margin-left: 0 !important;
                margin-top: 10px !important;
                display: block;
            }
        }

        @media (max-width: 480px) {
            .zic-card {
                padding: 15px;
            }

            .zic-stats-row {
                grid-template-columns: 1fr;
            }

            .zic-nav {
                gap: 20px;
            }

            .zic-checkbox-grid {
                grid-template-columns: 1fr;
            }

            .zic-input-text {
                max-width: 100%;
            }

            .zic-filter-box>div {
                flex-direction: column;
                align-items: flex-start;
                gap: 12px !important;
            }

            .zic-modal {
                width: 95% !important;
                max-height: 90vh;
                overflow-y: auto;
            }

            #tab-logs>.zic-card>div[style*="display:flex"] {
                flex-direction: column;
            }

            #tab-logs form button,
            #tab-logs button {
                width: 100%;
            }
        }
    </style>

    <div class="zic-wrap">
        <div class="zic-header">
            <div>
                <h1>智能媒体管理</h1>
                <p>扫描并清理未使用的媒体文件，释放服务器空间。</p>
            </div>
            <div>
                <a href="https://penx.cn" target="_blank" class="zic-btn zic-btn-secondary">
                    <span class="dashicons dashicons-admin-site-alt3"></span> 访问官网
                </a>
            </div>
        </div>

        <nav class="zic-nav">
            <a id="nav-settings" class="active" data-tab="settings">
                <span class="dashicons dashicons-admin-settings zic-nav-icon"></span> 设置
            </a>
            <a id="nav-scan" class="" data-tab="scan">
                <span class="dashicons dashicons-search zic-nav-icon"></span> 扫描与清理
            </a>
            <a id="nav-logs" class="" data-tab="logs">
                <span class="dashicons dashicons-text zic-nav-icon"></span> 运行日志
            </a>
        </nav>

        <div class="zic-tab-content">

            <div class="zic-tab-panel active" id="tab-settings">
                <form method="post">
                    <?php wp_nonce_field('zic_save_settings'); ?>

                    <div class="zic-card">
                        <div class="zic-card-title">
                            <span class="dashicons dashicons-controls-volumeon" style="color:#2563eb"></span> 基础设置
                        </div>

                        <div class="zic-form-group">
                            <label class="zic-form-label">启用的文章类型</label>
                            <p class="description" style="margin-bottom: 15px;">选择需要检测引用的文章类型。未选中的类型中的图片引用将被忽略。</p>
                            <div class="zic-checkbox-grid">
                                <?php foreach ($post_types as $type): ?>
                                    <label class="zic-checkbox-label">
                                        <input type="checkbox" name="zic_post_types[]"
                                            value="<?php echo esc_attr($type->name); ?>" <?php checked(in_array($type->name, $enabled_types)); ?> />
                                        <span><?php echo esc_html($type->labels->singular_name); ?></span>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>

                    <div class="zic-card">
                        <div class="zic-card-title">
                            <span class="dashicons dashicons-trash" style="color:#ef4444"></span> 清理策略
                        </div>

                        <div class="zic-form-group">
                            <label class="zic-checkbox-label" style="display:inline-flex; width: auto;">
                                <input type="checkbox" name="zic_delete_featured" value="1" <?php checked($delete_featured, '1'); ?> />
                                <span>删除文章时一并删除特色图片</span>
                            </label>
                        </div>

                        <div class="zic-form-group">
                            <label class="zic-form-label" for="zic_exclude_keywords">排除关键字</label>
                            <input type="text" name="zic_exclude_keywords" id="zic_exclude_keywords"
                                value="<?php echo esc_attr($exclude_keywords); ?>" class="zic-input-text"
                                placeholder="例如：logo.png, banner" />
                            <p class="description" style="margin-top: 8px;">包含这些关键字的图片 URL 将永远不会被扫描或删除。</p>
                        </div>
                    </div>

                    <div class="zic-card">
                        <div class="zic-card-title">
                            <span class="dashicons dashicons-admin-tools" style="color:#f59e0b"></span> 调试选项
                        </div>
                        <label class="zic-checkbox-label" style="display:inline-flex; width: auto;">
                            <input type="checkbox" name="zic_enable_log" value="1" <?php checked($enable_log, '1'); ?> />
                            <span>启用调试日志 (wp-content/debug.log)</span>
                        </label>
                    </div>

                    <div style="margin-top: 30px;">
                        <button type="submit" name="zic_save_settings" class="zic-btn zic-btn-primary zic-btn-lg">
                            <span class="dashicons dashicons-saved"></span> 保存设置
                        </button>
                    </div>
                </form>
            </div>

            <div class="zic-tab-panel" id="tab-scan">
                <div class="zic-card">
                    <div class="zic-card-title">
                        <span class="dashicons dashicons-filter" style="color:#2563eb"></span> 扫描控制
                    </div>

                    <div class="zic-filter-grid">
                        <div class="zic-filter-box">
                            <h4><span class="dashicons dashicons-flag"></span> 扫描模式</h4>
                            <div style="display: flex; gap: 30px;">
                                <label style="display:block; cursor: pointer;">
                                    <input type="checkbox" id="zic-show-unused" checked />
                                    <strong>扫描未使用的文件</strong>
                                </label>
                                <label style="display:block; color: #64748b; cursor: pointer;">
                                    <input type="checkbox" id="zic-show-referenced" />
                                    <strong>显示有引用的文件</strong>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="zic-action-bar">
                        <button type="button" id="zic-scan-btn" class="zic-btn zic-btn-primary zic-btn-lg">
                            <span class="dashicons dashicons-search"></span> 开始全量扫描
                        </button>
                        <span id="zic-scan-status"
                            style="font-weight: 500; color: #64748b; margin-left: 10px;">准备就绪，点击左侧按钮开始...</span>
                    </div>
                </div>

                <div id="zic-scan-results" style="display: none;">

                    <div id="zic-scan-summary-cards" class="zic-stats-row"></div>
                    <div id="zic-scan-summary" style="display:none;"></div>

                    <div class="zic-card" style="padding: 0; overflow: hidden; border:none; box-shadow:none;">
                        <div
                            style="padding: 16px 20px; border: 1px solid #e2e8f0; border-bottom: none; background: #fff; border-radius: 12px 12px 0 0; display: flex; justify-content: space-between; align-items: center;">
                            <label style="font-weight: 600; font-size: 14px; display:flex; align-items:center;">
                                <input type="checkbox" id="zic-select-all" style="margin-right:8px;" /> 全选
                            </label>
                            <button type="button" id="zic-delete-selected" class="zic-btn zic-btn-danger"
                                style="display: none;">
                                <span class="dashicons dashicons-trash"></span> 批量删除
                            </button>
                        </div>

                        <div id="zic-image-list" class="zic-table-container"
                            style="border: 1px solid #e2e8f0; border-top: 1px solid #e2e8f0; border-radius: 0 0 12px 12px; margin-top: 0; box-shadow:none;">
                            <div id="zic-images-table"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="zic-tab-panel" id="tab-logs">
                <div class="zic-card">
                    <div class="zic-card-title">
                        <span class="dashicons dashicons-list-view" style="color:#64748b"></span> 系统日志
                    </div>
                    <p class="description" style="margin-bottom: 20px;">查看插件的运行日志，帮助排查问题。日志文件位于
                        <code>wp-content/debug.log</code>
                    </p>

                    <div style="margin: 20px 0; display:flex; gap: 12px;">
                        <button type="button" id="zicCopyLogBtn" class="zic-btn zic-btn-secondary">
                            <span class="dashicons dashicons-admin-page"></span> 复制日志
                        </button>
                        <form method="post" style="display:inline-block;">
                            <?php wp_nonce_field('zic_save_settings'); ?>
                            <button type="submit" name="zic_clear_log" class="zic-btn zic-btn-secondary"
                                style="color:#ef4444; border-color: #fecaca;" onclick="return confirm('确定要清空日志吗？');">
                                <span class="dashicons dashicons-trash"></span> 清空日志
                            </button>
                        </form>
                    </div>

                    <div class="zic-log-container">
                        <div class="zic-log-header">
                            <span>CONSOLE OUTPUT (LAST 2000 LINES)</span>
                            <span>READ-ONLY</span>
                        </div>
                        <div class="zic-log-body">
                            <pre id="zicLogContent"><?php
                            if (function_exists('zic_get_log_content')) {
                                $log = zic_get_log_content(2000);
                                if (!empty($_POST['zic_log_search'])) {
                                    $kw = trim($_POST['zic_log_search']);
                                    $lines = explode("\n", $log);
                                    $log = '';
                                    foreach ($lines as $line) {
                                        if (stripos($line, $kw) !== false)
                                            $log .= $line . "\n";
                                    }
                                    if ($log === '')
                                        $log = '无匹配日志。';
                                }
                                echo esc_html($log);
                            } else {
                                echo '日志功能未启用或主插件未更新。';
                            }
                            ?></pre>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="zic-modal-overlay" id="zicSingleDeleteModal"
        style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 9999; background: rgba(15, 23, 42, 0.6); backdrop-filter: blur(4px);">
        <div class="zic-modal"
            style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; max-width: 480px; width: 90%; border-radius: 16px; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);">
            <div class="zic-modal-header" style="border-bottom: 1px solid #f1f5f9; padding: 24px;">
                <h3 class="zic-modal-title" style="margin:0; font-size: 20px; font-weight: 700; color: #1e293b;">删除确认</h3>
                <button type="button" class="zic-modal-close"
                    style="float: right; border:none; background:none; font-size:24px; cursor:pointer; color:#94a3b8;"
                    onclick="zicCloseModal('zicSingleDeleteModal')">&times;</button>
            </div>
            <div class="zic-modal-body" style="padding: 24px;">
                <p style="font-size: 15px; margin-top:0;">确定要删除该文件吗？</p>
                <div class="zic-delete-info"
                    style="background:#fff7ed; color:#c2410c; padding:16px; border-radius:8px; margin: 16px 0; font-size: 14px; border: 1px solid #ffedd5;">
                    <strong>⚠️ 注意：</strong>删除操作不可逆，请确认文件确实不再需要。
                </div>
                <div id="zic-single-delete-details" style="font-weight: 600; margin-top: 10px; color: #334155;"></div>
            </div>
            <div class="zic-modal-footer"
                style="text-align: right; border-top: 1px solid #f1f5f9; background: #f8fafc; padding: 16px 24px; border-radius: 0 0 16px 16px;">
                <button type="button" class="zic-btn zic-btn-secondary"
                    onclick="zicCloseModal('zicSingleDeleteModal')">取消</button>
                <button type="button" class="zic-btn zic-btn-danger" id="zic-confirm-single-delete"
                    style="margin-left: 12px;">确认删除</button>
            </div>
        </div>
    </div>

    <div class="zic-modal-overlay" id="zicBatchDeleteModal"
        style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 9999; background: rgba(15, 23, 42, 0.6); backdrop-filter: blur(4px);">
        <div class="zic-modal"
            style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; max-width: 480px; width: 90%; border-radius: 16px; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);">
            <div class="zic-modal-header" style="border-bottom: 1px solid #f1f5f9; padding: 24px;">
                <h3 class="zic-modal-title" style="margin:0; font-size: 20px; font-weight: 700; color: #1e293b;">批量删除</h3>
                <button type="button" class="zic-modal-close"
                    style="float: right; border:none; background:none; font-size:24px; cursor:pointer; color:#94a3b8;"
                    onclick="zicCloseModal('zicBatchDeleteModal')">&times;</button>
            </div>
            <div class="zic-modal-body" style="padding: 24px;">
                <p style="font-size: 15px; margin-top:0;">确定要删除选中的图片吗？</p>
                <div class="zic-delete-info"
                    style="background:#fff7ed; color:#c2410c; padding:16px; border-radius:8px; margin: 16px 0; font-size: 14px; border: 1px solid #ffedd5;">
                    <strong>⚠️ 警告：</strong>这些文件将被永久删除且无法恢复。
                </div>
                <div id="zic-batch-delete-details" style="font-weight: 600; color: #334155;"></div>
            </div>
            <div class="zic-modal-footer"
                style="text-align: right; border-top: 1px solid #f1f5f9; background: #f8fafc; padding: 16px 24px; border-radius: 0 0 16px 16px;">
                <button type="button" class="zic-btn zic-btn-secondary"
                    onclick="zicCloseModal('zicBatchDeleteModal')">取消</button>
                <button type="button" class="zic-btn zic-btn-danger" id="zic-confirm-batch-delete"
                    style="margin-left: 12px;">确认删除</button>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Tab 切换逻辑
            const tabButtons = document.querySelectorAll('.zic-nav a');
            const tabPanels = document.querySelectorAll('.zic-tab-panel');

            // 读取保存的标签页状态
            const savedTab = localStorage.getItem('zic_active_tab');
            if (savedTab) {
                const targetBtn = document.querySelector(`.zic-nav a[data-tab="${savedTab}"]`);
                if (targetBtn) switchTab(targetBtn);
            }

            // 绑定点击事件
            tabButtons.forEach(button => {
                button.addEventListener('click', function (e) {
                    e.preventDefault();
                    switchTab(this);
                    localStorage.setItem('zic_active_tab', this.getAttribute('data-tab'));
                });
            });

            function switchTab(clickedBtn) {
                const targetId = clickedBtn.getAttribute('data-tab');
                tabButtons.forEach(btn => btn.classList.remove('active'));
                tabPanels.forEach(panel => panel.classList.remove('active'));
                clickedBtn.classList.add('active');
                document.getElementById('tab-' + targetId).classList.add('active');
            }
        });

        function zicShowModal(modalId) {
            document.getElementById(modalId).style.display = 'block';
            document.body.style.overflow = 'hidden';
        }
        function zicCloseModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
            document.body.style.overflow = 'auto';
        }
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') {
                var modals = document.querySelectorAll('.zic-modal-overlay');
                modals.forEach(function (modal) {
                    if (modal.style.display === 'block') {
                        modal.style.display = 'none';
                        document.body.style.overflow = 'auto';
                    }
                });
            }
        });
        document.getElementById('zicCopyLogBtn').onclick = function () {
            var log = document.getElementById('zicLogContent').innerText;
            navigator.clipboard.writeText(log).then(function () {
                var originalHtml = document.getElementById('zicCopyLogBtn').innerHTML;
                document.getElementById('zicCopyLogBtn').innerHTML = '<span class="dashicons dashicons-yes"></span> 已复制';
                setTimeout(function () { document.getElementById('zicCopyLogBtn').innerHTML = originalHtml; }, 1500);
            });
        };

        // jQuery AJAX 逻辑
        jQuery(document).ready(function ($) {
            var scanNonce = '<?php echo wp_create_nonce('zic_scan_nonce'); ?>';
            var deleteNonce = '<?php echo wp_create_nonce('zic_delete_nonce'); ?>';

            // 扫描按钮
            $('#zic-scan-btn').on('click', function () {
                var $btn = $(this);
                var $status = $('#zic-scan-status');

                var filters = {
                    show_unused_images: $('#zic-show-unused').is(':checked'),
                    show_ghost_images: false,
                    show_referenced_images: $('#zic-show-referenced').is(':checked'),
                    min_file_size: 0,
                    max_file_size: 0,
                    date_from: '',
                    date_to: '',
                    file_types: []
                };

                $btn.prop('disabled', true).html('<span class="dashicons dashicons-update spin"></span> 全量扫描中...');
                $status.html('正在深度扫描媒体库，可能需要一些时间...');

                $.ajax({
                    url: ajaxurl, type: 'POST',
                    data: {
                        action: 'zic_scan_images', nonce: scanNonce,
                        ...filters
                    },
                    success: function (response) {
                        if (response.success) {
                            renderNewResults(response.data);
                            $status.html('<span style="color:#166534; font-weight:bold;">扫描完成</span>');
                        } else {
                            $status.html('<span style="color:#ef4444; font-weight:bold;">扫描失败: ' + (response.data || '未知错误') + '</span>');
                        }
                    },
                    error: function () { $status.html('<span style="color:#ef4444">网络错误</span>'); },
                    complete: function () { $btn.prop('disabled', false).html('<span class="dashicons dashicons-search"></span> 重新扫描'); }
                });
            });

            // 渲染结果
            function renderNewResults(data) {
                var $results = $('#zic-scan-results');
                var $cards = $('#zic-scan-summary-cards');
                var $table = $('#zic-images-table');

                var totalSize = 0, unusedCount = 0, referencedCount = 0;
                data.unused_images.forEach(function (img) {
                    if (img.type === 'unused') { unusedCount++; if (img.file_exists) totalSize += img.file_size; }
                    else if (img.type === 'referenced') referencedCount++;
                });

                var cardsHtml = `
                    <div class="zic-stat-card">
                        <span class="zic-stat-value">${data.total_attachments}</span>
                        <span class="zic-stat-label">总文件数</span>
                    </div>
                    <div class="zic-stat-card highlight">
                        <span class="zic-stat-value">${unusedCount}</span>
                        <span class="zic-stat-label">未使用文件</span>
                    </div>
                    <div class="zic-stat-card highlight">
                        <span class="zic-stat-value">${formatFileSize(totalSize)}</span>
                        <span class="zic-stat-label">可释放空间</span>
                    </div>
                    <div class="zic-stat-card">
                        <span class="zic-stat-value">${referencedCount}</span>
                        <span class="zic-stat-label">有引用</span>
                    </div>
                `;
                $cards.html(cardsHtml);

                if (data.unused_images.length > 0) {
                    var tableHtml = '<table class="zic-table">' +
                        '<thead><tr>' +
                        '<th style="width: 30px;"></th>' +
                        '<th style="width: 50px;">ID</th>' +
                        '<th style="width: 60px;">预览</th>' +
                        '<th>标题</th>' +
                        '<th style="width: 80px;">类型</th>' +
                        '<th style="width: 80px;">状态</th>' +
                        '<th style="width: 80px;">大小</th>' +
                        '<th style="width: 100px;">上传日期</th>' +
                        '<th style="width: 80px;">操作</th>' +
                        '</tr></thead><tbody>';

                    data.unused_images.forEach(function (img) {
                        var badge = '';
                        if (img.type === 'ghost') badge = '<span class="zic-badge zic-badge-ghost">文件丢失</span>';
                        else if (img.type === 'unused') badge = '<span class="zic-badge zic-badge-unused">未使用</span>';
                        else if (img.type === 'referenced') badge = '<span class="zic-badge zic-badge-referenced">已引用</span>';

                        var preview = '';
                        if (img.url.match(/\.(jpg|jpeg|png|gif|webp)$/i)) {
                            preview = `<a href="${img.url}" target="_blank"><img src="${img.url}" style="width:40px; height:40px; object-fit:cover; border-radius:6px; border:1px solid #e2e8f0;"></a>`;
                        } else {
                            preview = `<div style="width:40px; height:40px; background:#f1f5f9; border-radius:6px; display:flex; align-items:center; justify-content:center; font-size:10px; color:#64748b; font-weight:bold;">${img.file_extension}</div>`;
                        }

                        // 生成引用链接
                        var refInfo = '';
                        if (img.references && img.references.length > 0) {
                            var refLinks = [];
                            img.references.forEach(function (ref) {
                                var linkUrl = '#';
                                if (ref.type === 'user') {
                                    linkUrl = 'user-edit.php?user_id=' + (ref.user_id || ref.id.replace('user-', ''));
                                } else {
                                    linkUrl = 'post.php?post=' + ref.id + '&action=edit';
                                }
                                refLinks.push(`<a href="${linkUrl}" target="_blank" style="color:#2563eb; text-decoration:underline;">${ref.title}</a>`);
                            });
                            refInfo = `<div style="font-size:11px; color:#64748b; margin-top:4px; line-height:1.5;">引用: ${refLinks.join('，')}</div>`;
                        }

                        var displayTitle = img.title || '无标题';

                        var deleteBtn = (img.type === 'unused' || img.type === 'ghost') ?
                            `<button type="button" class="zic-btn zic-btn-sm zic-btn-ghost-danger zic-delete-single" data-id="${img.id}">删除</button>` : '';

                        var checkbox = (img.type === 'referenced') ? '' : `<input type="checkbox" class="zic-image-checkbox" value="${img.id}" style="transform:scale(1.1);">`;

                        tableHtml += `<tr data-id="${img.id}">
                            <td>${checkbox}</td>
                            <td style="color:#64748b; font-family:monospace; font-weight:bold;">${img.id}</td>
                            <td>${preview}</td>
                            <td>
                                <div style="font-weight:600; color:#334155;">${displayTitle}</div>
                                ${refInfo}
                            </td>
                            <td>
                                <span style="background:#f1f5f9; padding:2px 6px; border-radius:4px; font-size:11px; font-weight:600; color:#64748b;">${img.file_extension.toUpperCase()}</span>
                            </td>
                            <td>${badge}</td>
                            <td style="font-size:12px; color:#475569;">${formatFileSize(img.file_size)}</td>
                            <td style="font-size:12px; color:#64748b;">${img.upload_date.split(' ')[0]}</td>
                            <td>${deleteBtn}</td>
                        </tr>`;
                    });
                    tableHtml += '</tbody></table>';
                    $table.html(tableHtml);
                    $('#zic-delete-selected').show();
                } else {
                    $table.html('<div style="padding:60px; text-align:center; color:#64748b;"><span class="dashicons dashicons-yes" style="font-size:40px; width:40px; height:40px; color:#10b981; margin-bottom:10px;"></span><br>太棒了！没有发现未使用的文件。</div>');
                    $('#zic-delete-selected').hide();
                }
                $results.fadeIn();
                bindTableEvents();
            }

            function formatFileSize(bytes) {
                if (bytes === 0) return '0 B';
                var k = 1024, sizes = ['B', 'KB', 'MB', 'GB'], i = Math.floor(Math.log(bytes) / Math.log(k));
                return (bytes / Math.pow(k, i)).toPrecision(3) + ' ' + sizes[i];
            }

            function bindTableEvents() {
                $('#zic-select-all').off('change').on('change', function () {
                    $('.zic-image-checkbox').prop('checked', $(this).is(':checked'));
                    updateDeleteButton();
                });
                $(document).on('change', '.zic-image-checkbox', function () {
                    updateDeleteButton();
                    var total = $('.zic-image-checkbox').length;
                    var checked = $('.zic-image-checkbox:checked').length;
                    $('#zic-select-all').prop('checked', total > 0 && total === checked);
                });
                $(document).on('click', '.zic-delete-single', function () {
                    var id = $(this).data('id');
                    var $row = $(this).closest('tr');
                    var title = $row.find('td:eq(3) div:first').text();

                    $('#zic-single-delete-details').html(`<strong>${title}</strong> (ID: ${id})`);
                    $('#zic-confirm-single-delete').off('click').on('click', function () {
                        zicCloseModal('zicSingleDeleteModal');
                        deleteImages([id]);
                    });
                    zicShowModal('zicSingleDeleteModal');
                });

                $('#zic-delete-selected').off('click').on('click', function () {
                    var selectedIds = [];
                    $('.zic-image-checkbox:checked').each(function () { selectedIds.push($(this).val()); });
                    if (selectedIds.length === 0) return;

                    $('#zic-batch-delete-details').html(`共选中 <strong>${selectedIds.length}</strong> 个文件`);
                    $('#zic-confirm-batch-delete').off('click').on('click', function () {
                        zicCloseModal('zicBatchDeleteModal');
                        deleteImages(selectedIds);
                    });
                    zicShowModal('zicBatchDeleteModal');
                });
            }

            function updateDeleteButton() {
                var c = $('.zic-image-checkbox:checked').length;
                var $btn = $('#zic-delete-selected');
                if (c > 0) { $btn.show().html(`<span class="dashicons dashicons-trash"></span> 批量删除 (${c})`); }
                else { $btn.hide(); }
            }

            function deleteImages(ids) {
                $.ajax({
                    url: ajaxurl, type: 'POST',
                    data: { action: 'zic_delete_images', nonce: deleteNonce, image_ids: ids },
                    success: function (res) {
                        if (res.success) {
                            ids.forEach(id => $('tr[data-id="' + id + '"]').fadeOut());
                        } else {
                            alert('删除失败');
                        }
                    }
                });
            }
        });
    </script>
    <?php
}