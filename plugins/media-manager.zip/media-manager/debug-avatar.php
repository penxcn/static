<?php
/**
 * 头像检测调试工具
 * 在浏览器访问: http://您的域名/wp-content/plugins/image-cleaner/debug-avatar.php
 */

// 加载WordPress
require_once('../../../wp-load.php');

// 检查权限
if (!current_user_can('manage_options')) {
    wp_die('权限不足');
}

global $wpdb;

// 获取参数
$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 1;
$attachment_id = isset($_GET['attachment_id']) ? intval($_GET['attachment_id']) : 0;

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>头像检测调试工具</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background: #f5f5f5;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
        }

        h1 {
            color: #333;
            border-bottom: 3px solid #0073aa;
            padding-bottom: 10px;
        }

        h2 {
            color: #0073aa;
            margin-top: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background: white;
        }

        th,
        td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background: #0073aa;
            color: white;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background: #f9f9f9;
        }

        .highlight {
            background: #ffffcc !important;
            font-weight: bold;
        }

        .form-group {
            margin: 20px 0;
        }

        .form-group label {
            display: inline-block;
            width: 150px;
            font-weight: bold;
        }

        .form-group input {
            padding: 8px;
            width: 200px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .btn {
            padding: 10px 20px;
            background: #0073aa;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .btn:hover {
            background: #005a87;
        }

        .info {
            background: #e7f3ff;
            padding: 15px;
            border-left: 4px solid #0073aa;
            margin: 20px 0;
        }

        .warning {
            background: #fff3cd;
            padding: 15px;
            border-left: 4px solid #ffc107;
            margin: 20px 0;
        }

        .success {
            background: #d4edda;
            padding: 15px;
            border-left: 4px solid #28a745;
            margin: 20px 0;
        }

        .error {
            background: #f8d7da;
            padding: 15px;
            border-left: 4px solid #dc3545;
            margin: 20px 0;
        }

        code {
            background: #f4f4f4;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: monospace;
        }

        .sql-box {
            background: #2d2d2d;
            color: #f8f8f8;
            padding: 15px;
            border-radius: 4px;
            overflow-x: auto;
        }

        .sql-box code {
            background: transparent;
            color: #f8f8f8;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>🔍 头像检测调试工具</h1>

        <div class="info">
            <strong>使用说明：</strong>
            <ul>
                <li>输入用户ID查看该用户的所有meta数据</li>
                <li>输入附件ID查看哪些用户正在使用该图片</li>
                <li>查看日志了解插件的检测过程</li>
            </ul>
        </div>

        <form method="get">
            <div class="form-group">
                <label>用户ID:</label>
                <input type="number" name="user_id" value="<?php echo $user_id; ?>" min="1">
            </div>
            <div class="form-group">
                <label>附件ID:</label>
                <input type="number" name="attachment_id" value="<?php echo $attachment_id; ?>">
            </div>
            <button type="submit" class="btn">🔍 开始检测</button>
        </form>

        <?php
        // 查询1: 用户的所有meta数据
        echo "<h2>📋 用户 #{$user_id} 的所有Meta数据</h2>";
        $user_meta_sql = $wpdb->prepare("SELECT meta_key, meta_value FROM $wpdb->usermeta WHERE user_id = %d ORDER BY meta_key", $user_id);
        $user_metas = $wpdb->get_results($user_meta_sql);

        // 定义排除字段（与插件保持一致）
        $excluded_fields = array(
            'wp_capabilities',
            'wp_user_level',
            'session_tokens',
            'wp_metronet_image_id',
            'wp_persisted_preferences',
            'wp_user-settings',
            'wp_user-settings-time',
            'wp_dashboard_quick_press_last_post_id',
            'community-events-location',
            'dismissed_wp_pointers'
        );

        if ($user_metas) {
            echo '<table>';
            echo '<tr><th>字段名 (meta_key)</th><th>值 (meta_value)</th><th>说明</th></tr>';
            foreach ($user_metas as $meta) {
                $is_numeric = is_numeric($meta->meta_value);
                $is_url = strpos($meta->meta_value, 'http') === 0;
                $is_serialized = strpos($meta->meta_value, 'a:') === 0;
                $is_excluded = in_array($meta->meta_key, $excluded_fields);

                $description = '';
                $highlight_class = '';

                if ($is_excluded) {
                    $description = '🚫 系统字段（已排除，不检测）';
                    $highlight_class = '';
                } elseif ($is_numeric && $meta->meta_value > 0) {
                    // 检查是否是附件
                    $check_attachment = $wpdb->get_var($wpdb->prepare("SELECT post_title FROM $wpdb->posts WHERE ID = %d AND post_type = 'attachment'", $meta->meta_value));
                    if ($check_attachment) {
                        $description = '✅ 可能是附件ID: ' . $check_attachment;
                        $highlight_class = 'highlight';
                    }
                } elseif ($is_url) {
                    $description = '🔗 URL地址';
                    $highlight_class = 'highlight';
                } elseif ($is_serialized) {
                    $description = '📦 序列化数据';
                }

                echo '<tr class="' . $highlight_class . '">';
                echo '<td><code>' . esc_html($meta->meta_key) . '</code></td>';
                echo '<td>' . esc_html(substr($meta->meta_value, 0, 100)) . (strlen($meta->meta_value) > 100 ? '...' : '') . '</td>';
                echo '<td>' . $description . '</td>';
                echo '</tr>';
            }
            echo '</table>';

            echo '<div class="info">';
            echo '<strong>🚫 已排除的系统字段：</strong> ';
            echo implode(', ', array_map(function ($f) {
                return '<code>' . $f . '</code>';
            }, $excluded_fields));
            echo '<br><br>这些字段不会被检测为图片引用，因为它们存储的是系统设置，不是真正的图片。';
            echo '</div>';
        } else {
            echo '<p class="warning">未找到该用户的meta数据</p>';
        }

        // 查询2: 如果提供了附件ID，查找哪些用户在使用
        if ($attachment_id > 0) {
            echo "<h2>🔎 查找使用附件 #{$attachment_id} 的用户</h2>";

            // 获取附件信息
            $attachment = $wpdb->get_row($wpdb->prepare("SELECT post_title, guid FROM $wpdb->posts WHERE ID = %d", $attachment_id));
            if ($attachment) {
                echo '<div class="success">';
                echo '<strong>附件信息：</strong><br>';
                echo '标题: ' . esc_html($attachment->post_title) . '<br>';
                echo 'URL: ' . esc_html($attachment->guid);
                echo '</div>';

                // 检测1: 通过附件ID（整数和字符串）
                echo '<h3>方法1: 通过附件ID检测</h3>';
                $id_search_sql = $wpdb->prepare(
                    "SELECT u.ID, u.display_name, u.user_login, um.meta_key, um.meta_value
                    FROM $wpdb->usermeta um
                    JOIN $wpdb->users u ON um.user_id = u.ID
                    WHERE (um.meta_value = %d OR um.meta_value = %s)
                    AND um.meta_key NOT IN ('wp_capabilities', 'wp_user_level', 'session_tokens')",
                    $attachment_id,
                    (string) $attachment_id
                );
                $id_results = $wpdb->get_results($id_search_sql);

                if ($id_results) {
                    echo '<div class="success">✅ 找到 ' . count($id_results) . ' 个引用！</div>';
                    echo '<table>';
                    echo '<tr><th>用户ID</th><th>用户名</th><th>字段名</th><th>字段值</th></tr>';
                    foreach ($id_results as $result) {
                        echo '<tr class="highlight">';
                        echo '<td>' . $result->ID . '</td>';
                        echo '<td>' . esc_html($result->display_name) . ' (' . esc_html($result->user_login) . ')</td>';
                        echo '<td><code>' . esc_html($result->meta_key) . '</code></td>';
                        echo '<td>' . esc_html($result->meta_value) . '</td>';
                        echo '</tr>';
                    }
                    echo '</table>';
                } else {
                    echo '<p class="warning">⚠️ 未通过附件ID找到引用</p>';
                }

                // 检测2: 通过URL
                echo '<h3>方法2: 通过URL检测</h3>';
                $url = $attachment->guid;
                $url_search_sql = $wpdb->prepare(
                    "SELECT u.ID, u.display_name, u.user_login, um.meta_key, um.meta_value
                    FROM $wpdb->usermeta um
                    JOIN $wpdb->users u ON um.user_id = u.ID
                    WHERE um.meta_value LIKE %s",
                    '%' . $wpdb->esc_like($url) . '%'
                );
                $url_results = $wpdb->get_results($url_search_sql);

                if ($url_results) {
                    echo '<div class="success">✅ 找到 ' . count($url_results) . ' 个引用！</div>';
                    echo '<table>';
                    echo '<tr><th>用户ID</th><th>用户名</th><th>字段名</th><th>字段值</th></tr>';
                    foreach ($url_results as $result) {
                        echo '<tr class="highlight">';
                        echo '<td>' . $result->ID . '</td>';
                        echo '<td>' . esc_html($result->display_name) . ' (' . esc_html($result->user_login) . ')</td>';
                        echo '<td><code>' . esc_html($result->meta_key) . '</code></td>';
                        echo '<td>' . esc_html(substr($result->meta_value, 0, 100)) . '...</td>';
                        echo '</tr>';
                    }
                    echo '</table>';
                } else {
                    echo '<p class="warning">⚠️ 未通过URL找到引用</p>';
                }

                // 检测3: 序列化数据
                echo '<h3>方法3: 序列化数据检测</h3>';
                $serialized_sql = "SELECT u.ID, u.display_name, u.user_login, um.meta_key, um.meta_value
                    FROM $wpdb->usermeta um
                    JOIN $wpdb->users u ON um.user_id = u.ID
                    WHERE um.meta_value LIKE 'a:%'
                    AND um.meta_value LIKE '%" . $wpdb->esc_like((string) $attachment_id) . "%'";
                $serialized_results = $wpdb->get_results($serialized_sql);

                if ($serialized_results) {
                    echo '<div class="success">✅ 找到 ' . count($serialized_results) . ' 个可能的序列化引用！</div>';
                    echo '<table>';
                    echo '<tr><th>用户ID</th><th>用户名</th><th>字段名</th><th>反序列化后的内容</th></tr>';
                    foreach ($serialized_results as $result) {
                        $unserialized = @maybe_unserialize($result->meta_value);
                        echo '<tr class="highlight">';
                        echo '<td>' . $result->ID . '</td>';
                        echo '<td>' . esc_html($result->display_name) . ' (' . esc_html($result->user_login) . ')</td>';
                        echo '<td><code>' . esc_html($result->meta_key) . '</code></td>';
                        echo '<td><pre>' . esc_html(print_r($unserialized, true)) . '</pre></td>';
                        echo '</tr>';
                    }
                    echo '</table>';
                } else {
                    echo '<p class="warning">⚠️ 未在序列化数据中找到引用</p>';
                }

            } else {
                echo '<p class="error">❌ 附件ID不存在</p>';
            }
        }

        // 查询3: 显示所有可能的头像字段
        echo '<h2>📊 数据库中所有可能的头像/图片字段</h2>';
        $avatar_fields_sql = "SELECT DISTINCT meta_key, COUNT(*) as count 
            FROM $wpdb->usermeta 
            WHERE meta_key LIKE '%avatar%' 
               OR meta_key LIKE '%cover%'
               OR meta_key LIKE '%picture%'
               OR meta_key LIKE '%image%'
               OR meta_key LIKE '%photo%'
            GROUP BY meta_key
            ORDER BY count DESC, meta_key";
        $avatar_fields = $wpdb->get_results($avatar_fields_sql);

        if ($avatar_fields) {
            echo '<table>';
            echo '<tr><th>字段名</th><th>使用次数</th><th>是否在插件中</th></tr>';

            $plugin_fields = array(
                'wp_user_avatar',
                'simple_local_avatar',
                'avatar',
                'user_avatar',
                'custom_avatar',
                'profile_picture',
                'user_cover',
                'cover_image',
                'banner_image'
            );

            foreach ($avatar_fields as $field) {
                $in_plugin = in_array($field->meta_key, $plugin_fields);
                $status = $in_plugin ? '✅ 已支持' : '❌ 未支持';
                $class = $in_plugin ? '' : 'warning';

                echo '<tr class="' . $class . '">';
                echo '<td><code>' . esc_html($field->meta_key) . '</code></td>';
                echo '<td>' . $field->count . '</td>';
                echo '<td>' . $status . '</td>';
                echo '</tr>';
            }
            echo '</table>';

            echo '<div class="info">';
            echo '<strong>💡 提示：</strong>如果看到❌未支持的字段，请将其添加到插件的 <code>$avatar_meta_keys</code> 数组中（约在 image-cleaner.php 第898行）';
            echo '</div>';
        }

        // SQL查询示例
        echo '<h2>💻 可用的SQL诊断查询</h2>';
        echo '<div class="sql-box">';
        echo '<p><strong>1. 查看特定用户的所有meta:</strong></p>';
        echo '<code>SELECT * FROM ' . $wpdb->usermeta . ' WHERE user_id = 1;</code><br><br>';

        echo '<p><strong>2. 查找所有头像相关字段:</strong></p>';
        echo '<code>SELECT DISTINCT meta_key FROM ' . $wpdb->usermeta . ' WHERE meta_key LIKE \'%avatar%\';</code><br><br>';

        echo '<p><strong>3. 查找使用特定附件ID的用户:</strong></p>';
        echo '<code>SELECT u.*, um.meta_key, um.meta_value FROM ' . $wpdb->usermeta . ' um JOIN ' . $wpdb->users . ' u ON um.user_id = u.ID WHERE um.meta_value = \'123\';</code>';
        echo '</div>';
        ?>

        <p style="margin-top: 40px; padding-top: 20px; border-top: 2px solid #ddd; color: #666;">
            <strong>调试完成后：</strong><br>
            1. 查看日志: WordPress后台 → 智能媒体管理 → 日志<br>
            2. 如果发现新的头像字段，请添加到插件代码中<br>
            3. 完成调试后可以删除此文件
        </p>
    </div>
</body>

</html>