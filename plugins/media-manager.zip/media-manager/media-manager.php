<?php
/*
Plugin Name: 智能媒体管理
Description: 一款专业的 WordPress 媒体库清理工具，帮助您智能识别和清理未使用的媒体文件，释放宝贵的服务器空间。
Version: 2.0.0
Author: 惊鸿博客
Plugin URI:  https://penx.cn
Author URI:  https://penx.cn
QQ: 484188846
*/
if (!defined('ABSPATH'))
    exit;

define('ZIC_PLUGIN_DIR', plugin_dir_path(__FILE__));

// 加载设置页面
require_once ZIC_PLUGIN_DIR . 'admin-settings.php';

// 插件激活时记录日志
register_activation_hook(__FILE__, function () {
    zic_log("智能媒体管理 插件已激活");
});

// 插件初始化时记录日志
add_action('init', function () {
    if (is_admin() && isset($_GET['page']) && $_GET['page'] === 'image-cleaner') {
        zic_log("访问 智能媒体管理 设置页面");
    }
});

// 获取启用的文章类型
function zic_get_enabled_post_types()
{
    $types = get_option('zic_enabled_post_types');
    if (!$types || !is_array($types)) {
        $types = array('post', 'page');
    }
    return $types;
}

// 通用函数：检查图片是否被文章引用
function zic_check_image_references($image_url, $exclude_post_id = 0)
{
    global $wpdb;
    $enabled_types = zic_get_enabled_post_types();
    $post_types_escaped = array_map(function ($t) use ($wpdb) {
        return "'" . esc_sql($t) . "'";
    }, $enabled_types);
    $in_types = implode(',', $post_types_escaped);
    $like_img_url = '%' . $wpdb->esc_like($image_url) . '%';

    $sql = $wpdb->prepare(
        "SELECT ID FROM $wpdb->posts WHERE ID != %d AND post_type IN ($in_types) AND post_status IN ('publish','draft','pending','future') AND post_content LIKE %s LIMIT 1",
        $exclude_post_id,
        $like_img_url
    );

    return $wpdb->get_results($sql);
}

// 通用函数：强制删除附件
function zic_force_delete_attachment($attachment_id)
{
    global $wpdb;
    $deleted = wp_delete_attachment($attachment_id, true);
    if ($deleted) {
        zic_log("成功删除附件ID：$attachment_id");
        return true;
    } else {
        zic_log("删除附件失败，尝试强制删除ID：$attachment_id");
        $del1 = $wpdb->delete($wpdb->posts, array('ID' => $attachment_id, 'post_type' => 'attachment'));
        $del2 = $wpdb->delete($wpdb->postmeta, array('post_id' => $attachment_id));
        if ($del1)
            zic_log("强制删除附件记录：$attachment_id");
        if ($del2)
            zic_log("强制删除附件元数据：$attachment_id");
        return $del1 || $del2;
    }
}

// 简单日志函数，按设置决定是否写入（中文说明）
function zic_log($msg)
{
    $enable_log = get_option('zic_enable_log', '1');
    if ($enable_log !== '1')
        return;

    if (!is_string($msg))
        $msg = print_r($msg, true);

    $log_file = WP_CONTENT_DIR . '/debug.log';
    $log_content = '[' . date('Y-m-d H:i:s') . '] [ZIC] ' . $msg . "\n";

    // 尝试写入日志文件
    $result = file_put_contents($log_file, $log_content, FILE_APPEND | LOCK_EX);

    // 如果写入失败，尝试使用error_log
    if ($result === false) {
        error_log('[ZIC] ' . $msg);
    }
}

// 获取日志内容
function zic_get_log_content($lines = 200)
{
    $log_file = WP_CONTENT_DIR . '/debug.log';
    if (!file_exists($log_file))
        return '日志文件不存在';

    $content = file($log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (!$content) {
        return '日志文件为空';
    }

    $total = count($content);
    $start = max(0, $total - $lines);
    $selected_lines = array_slice($content, $start);

    return implode("\n", $selected_lines) . "\n";
}

// 删除文章时处理图片（切换为 delete_post 钩子）
function zic_handle_post_delete($post_id)
{
    $post = get_post($post_id);
    if (!$post) {
        zic_log("未找到文章ID：$post_id");
        return;
    }
    $enabled_types = zic_get_enabled_post_types();
    if (!in_array($post->post_type, $enabled_types)) {
        zic_log("未启用的文章类型：{$post->post_type}");
        return;
    }

    // 获取排除关键字
    $exclude_keywords = get_option('zic_exclude_keywords', '');
    $exclude_arr = array_filter(array_map('trim', explode(',', $exclude_keywords)));

    // 提取内容图片URL
    $content = $post->post_content;
    preg_match_all('/<img[^>]+src=["\']([^"\']+)["\']/i', $content, $matches);
    $image_urls = $matches[1];

    // 处理特色图片
    $delete_featured = get_option('zic_delete_featured', '1');
    $thumb_id = get_post_thumbnail_id($post_id);
    if ($thumb_id && $delete_featured === '1') {
        $thumb_url = wp_get_attachment_url($thumb_id);
        if ($thumb_url && !in_array($thumb_url, $image_urls)) {
            $image_urls[] = $thumb_url;
        }
    }

    // 删除孤立附件（post_parent为当前文章ID的附件）
    global $wpdb;
    $orphans = $wpdb->get_results($wpdb->prepare("SELECT ID FROM $wpdb->posts WHERE post_type='attachment' AND post_parent=%d", $post_id));
    foreach ($orphans as $att) {
        zic_force_delete_attachment($att->ID);
    }

    // 处理内容中的图片
    foreach ($image_urls as $img_url) {
        // 排除关键字检查
        $skip = false;
        foreach ($exclude_arr as $kw) {
            if ($kw && stripos($img_url, $kw) !== false) {
                zic_log("因关键字[$kw]跳过图片：$img_url");
                $skip = true;
                break;
            }
        }
        if ($skip)
            continue;

        // 查找图片对应的附件 ID
        $attachment_id = attachment_url_to_postid($img_url);
        if (!$attachment_id) {
            // 尝试回溯原图
            if (preg_match('/(.*)-([0-9]+)x([0-9]+)(\.[a-zA-Z0-9]+)$/', $img_url, $m)) {
                $original_url = $m[1] . $m[4];
                $attachment_id = attachment_url_to_postid($original_url);
            }
        }
        if (!$attachment_id) {
            zic_log("未找到附件：$img_url");
            continue;
        }

        // 检查是否被其他文章引用
        $results = zic_check_image_references($img_url, $post_id);
        if (empty($results)) {
            // 没有被其他文章引用，删除附件
            zic_force_delete_attachment($attachment_id);
        } else {
            // 被其他文章引用，仅解除上传者关联
            $updated = $wpdb->update($wpdb->posts, array('post_parent' => 0), array('ID' => $attachment_id, 'post_type' => 'attachment'));
            if ($updated !== false) {
                zic_log("图片 $attachment_id 被其他文章引用，已解除上传者关联");
            }
        }
    }
}
remove_action('before_delete_post', 'zic_handle_post_delete');
add_action('delete_post', 'zic_handle_post_delete');

// 拦截媒体库删除图片操作，若被引用则阻止删除
add_filter('pre_delete_attachment', function ($delete, $post_id) {
    // 只在后台媒体库操作时生效
    if (!is_admin())
        return $delete;

    $img_url = wp_get_attachment_url($post_id);
    if (!$img_url)
        return $delete;

    $results = zic_check_image_references($img_url);
    if (!empty($results)) {
        // 被引用，阻止删除
        add_filter('redirect_post_location', function ($location) {
            return add_query_arg('ic_img_in_use', '1', $location);
        });
        return new WP_Error('ic_img_in_use', __('该图片仍被文章引用，不能删除。', 'image-cleaner'));
    }
    return $delete;
}, 10, 2);

// 在媒体库页面显示提示
add_action('admin_notices', function () {
    if (isset($_GET['ic_img_in_use']) && $_GET['ic_img_in_use'] == '1') {
        echo '<div class="notice notice-error is-dismissible"><p>该图片仍被文章引用，不能删除。</p></div>';
    }
});

// 添加设置页面菜单
add_action('admin_menu', function () {
    add_menu_page(
        '智能媒体管理', // 页面标题
        '智能媒体管理',              // 菜单标题
        'manage_options',
        'image-cleaner',
        'zic_settings_page',
        'dashicons-admin-media  ',      // 管理资源图标
    );
});

// 日志下载处理
add_action('admin_init', function () {
    if (isset($_GET['zic_download_log']) && $_GET['zic_download_log'] == '1' && isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'zic_download_log')) {
        $log_file = WP_CONTENT_DIR . '/debug.log';
        if (!file_exists($log_file)) {
            wp_die('日志文件不存在');
        }
        header('Content-Description: File Transfer');
        header('Content-Type: text/plain');
        header('Content-Disposition: attachment; filename=debug.log');
        header('Content-Length: ' . filesize($log_file));
        readfile($log_file);
        exit;
    }
});

// 插入原生仿 Bootstrap5 风格弹窗并拦截删除操作
add_action('admin_footer', function () {
    global $pagenow;
    if (in_array($pagenow, ['edit.php', 'post.php'])) {
        ?>
        <style>
            .zic-modal-fade {
                display: none;
                position: fixed;
                z-index: 9999;
                left: 0;
                top: 0;
                width: 100vw;
                height: 100vh;
                background: rgba(0, 0, 0, 0.3);
                transition: opacity .2s;
            }

            .zic-modal-fade.show {
                display: block;
                opacity: 1;
            }

            .zic-modal-fade.hide {
                opacity: 0;
            }

            .zic-modal-dialog {
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                max-width: 400px;
                width: 90vw;
            }

            .zic-modal-content {
                background: #fff;
                border-radius: .5rem;
                box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, .15);
                overflow: hidden;
            }

            .zic-modal-header {
                padding: 1rem 1.5rem;
                border-bottom: 1px solid #dee2e6;
                display: flex;
                align-items: center;
                justify-content: space-between;
            }

            .zic-modal-title {
                font-size: 1.25rem;
                font-weight: 500;
            }

            .zic-modal-close {
                background: none;
                border: none;
                font-size: 1.5rem;
                line-height: 1;
                color: #000;
                opacity: .5;
                cursor: pointer;
            }

            .zic-modal-close:hover {
                opacity: .8;
            }

            .zic-modal-body {
                padding: 1rem 1.5rem;
                font-size: 1rem;
            }

            .zic-modal-footer {
                padding: 0.75rem 1.5rem;
                border-top: 1px solid #dee2e6;
                text-align: right;
            }

            .zic-btn {
                display: inline-block;
                font-weight: 400;
                text-align: center;
                vertical-align: middle;
                user-select: none;
                border: 1px solid transparent;
                padding: 0.375rem 0.75rem;
                font-size: 1rem;
                line-height: 1.5;
                border-radius: 0.375rem;
                transition: background .15s;
                cursor: pointer;
            }

            .zic-btn-secondary {
                color: #fff;
                background: #6c757d;
                border-color: #6c757d;
            }

            .zic-btn-secondary:hover {
                background: #5a6268;
            }

            .zic-btn-danger {
                color: #fff;
                background: #dc3545;
                border-color: #dc3545;
            }

            .zic-btn-danger:hover {
                background: #bb2d3b;
            }
        </style>
        <div class="zic-modal-fade" id="zicDeleteModal">
            <div class="zic-modal-dialog">
                <div class="zic-modal-content">
                    <div class="zic-modal-header">
                        <span class="zic-modal-title">删除确认</span>
                        <button type="button" class="zic-modal-close" id="zicDeleteModalClose"
                            aria-label="Close">&times;</button>
                    </div>
                    <div class="zic-modal-body">
                        确定要删除该文章？<br>同时会删除文章内容和特色图片中未被其他文章引用的图片。
                    </div>
                    <div class="zic-modal-footer">
                        <button type="button" class="zic-btn zic-btn-secondary" id="zicDeleteCancelBtn">取消</button>
                        <button type="button" class="zic-btn zic-btn-danger" id="zicDeleteConfirmBtn">确认删除</button>
                    </div>
                </div>
            </div>
        </div>
        <script>
            (function () {
                let pendingDeleteHref = null;
                let pendingDeleteForm = null;
                var modal = document.getElementById('zicDeleteModal');
                var confirmBtn = document.getElementById('zicDeleteConfirmBtn');
                var cancelBtn = document.getElementById('zicDeleteCancelBtn');
                var closeBtn = document.getElementById('zicDeleteModalClose');
                function showModal(cb) {
                    modal.classList.add('show');
                    modal.classList.remove('hide');
                    confirmBtn.onclick = function () { hideModal(); if (cb) cb(); };
                    cancelBtn.onclick = closeBtn.onclick = hideModal;
                }
                function hideModal() {
                    modal.classList.add('hide');
                    modal.classList.remove('show');
                    setTimeout(function () { modal.classList.remove('hide'); modal.style.display = 'none'; }, 200);
                }
                // 列表页删除按钮
                document.querySelectorAll('a.submitdelete').forEach(function (btn) {
                    btn.addEventListener('click', function (e) {
                        e.preventDefault();
                        pendingDeleteHref = btn.href;
                        modal.style.display = 'block';
                        setTimeout(function () { showModal(function () { window.location.href = pendingDeleteHref; }); }, 10);
                    });
                });
                // 编辑页删除按钮
                var form = document.getElementById('deletepost');
                if (form) {
                    form.addEventListener('submit', function (e) {
                        e.preventDefault();
                        pendingDeleteForm = form;
                        modal.style.display = 'block';
                        setTimeout(function () { showModal(function () { pendingDeleteForm.submit(); }); }, 10);
                    });
                }
            })();
        </script>
        <?php
    }
});

add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($links) {
    $settings_link = '<a href="admin.php?page=image-cleaner">设置</a>';
    array_unshift($links, $settings_link);
    return $links;
});

// 扫描媒体库中未被引用的图片
function zic_scan_unused_images($filters = array())
{
    global $wpdb;

    $enabled_types = zic_get_enabled_post_types();
    $exclude_keywords = get_option('zic_exclude_keywords', '');
    $exclude_arr = array_filter(array_map('trim', explode(',', $exclude_keywords)));

    // 默认筛选条件
    $default_filters = array(
        'show_ghost_images' => false,  // 是否显示幽灵图片（文件丢失）
        'show_unused_images' => true,  // 是否显示未使用的图片
        'show_referenced_images' => false,  // 是否显示有引用的图片
        'min_file_size' => 0,          // 最小文件大小（字节）
        'max_file_size' => 0,          // 最大文件大小（字节），0表示无限制
        'date_from' => '',             // 上传日期从
        'date_to' => '',               // 上传日期到
        'file_types' => array()        // 文件类型筛选
    );

    $filters = wp_parse_args($filters, $default_filters);

    // 记录筛选条件
    zic_log("扫描筛选条件: " . json_encode($filters));

    // 获取所有附件
    $attachments = $wpdb->get_results("
        SELECT ID, post_title, guid, post_parent 
        FROM $wpdb->posts 
        WHERE post_type = 'attachment' 
        AND post_status = 'inherit'
        ORDER BY ID DESC
    ");

    zic_log("开始扫描，总附件数量: " . count($attachments));

    $unused_images = array();
    $referenced_images = array();
    $ghost_images = array();
    $total_attachments = count($attachments);

    foreach ($attachments as $attachment) {
        $attachment_url = wp_get_attachment_url($attachment->ID);
        if (!$attachment_url) {
            continue;
        }

        // 检查排除关键字
        $skip = false;
        foreach ($exclude_arr as $kw) {
            if ($kw && stripos($attachment_url, $kw) !== false) {
                $skip = true;
                break;
            }
        }
        if ($skip) {
            continue;
        }

        // 获取文件信息
        $file_path = get_attached_file($attachment->ID);
        $file_exists = $file_path && file_exists($file_path);
        $file_size = $file_exists ? filesize($file_path) : 0;
        $upload_date = get_the_date('Y-m-d H:i:s', $attachment->ID);
        $file_extension = pathinfo($attachment_url, PATHINFO_EXTENSION);

        // 检查是否为幽灵图片（文件丢失）
        if (!$file_exists) {
            if ($filters['show_ghost_images']) {
                $ghost_images[] = array(
                    'id' => $attachment->ID,
                    'title' => $attachment->post_title,
                    'url' => $attachment_url,
                    'file_size' => 0,
                    'upload_date' => $upload_date,
                    'parent_post' => $attachment->post_parent,
                    'file_exists' => false,
                    'file_extension' => $file_extension,
                    'type' => 'ghost'
                );
            }
            continue; // 幽灵图片不参与未使用图片的检查
        }

        // 文件大小筛选
        if ($filters['min_file_size'] > 0 && $file_size < $filters['min_file_size']) {
            continue;
        }
        if ($filters['max_file_size'] > 0 && $file_size > $filters['max_file_size']) {
            continue;
        }

        // 日期筛选
        if ($filters['date_from'] && strtotime($upload_date) < strtotime($filters['date_from'])) {
            continue;
        }
        if ($filters['date_to'] && strtotime($upload_date) > strtotime($filters['date_to'])) {
            continue;
        }

        // 文件类型筛选
        if (!empty($filters['file_types']) && !in_array(strtolower($file_extension), array_map('strtolower', $filters['file_types']))) {
            continue;
        }

        // 检查引用情况
        $all_references = zic_get_image_references($attachment->ID, $attachment_url, $enabled_types);

        // 根据筛选条件决定是否添加到结果中
        $has_references = !empty($all_references);

        if (!$has_references) {
            // 没有引用的图片
            if ($filters['show_unused_images']) {
                $unused_images[] = array(
                    'id' => $attachment->ID,
                    'title' => $attachment->post_title,
                    'url' => $attachment_url,
                    'file_size' => $file_size,
                    'upload_date' => $upload_date,
                    'parent_post' => $attachment->post_parent,
                    'file_exists' => true,
                    'file_extension' => $file_extension,
                    'type' => 'unused',
                    'references' => array()
                );
            }
        } else {
            // 有引用的图片
            if ($filters['show_referenced_images']) {
                $referenced_images[] = array(
                    'id' => $attachment->ID,
                    'title' => $attachment->post_title,
                    'url' => $attachment_url,
                    'file_size' => $file_size,
                    'upload_date' => $upload_date,
                    'parent_post' => $attachment->post_parent,
                    'file_exists' => true,
                    'file_extension' => $file_extension,
                    'type' => 'referenced',
                    'references' => $all_references
                );
            }
        }
    }

    // 合并结果
    $all_images = array_merge($unused_images, $referenced_images, $ghost_images);

    // 记录扫描结果
    zic_log("扫描完成，未使用图片: " . count($unused_images) . "，有引用图片: " . count($referenced_images) . "，幽灵图片: " . count($ghost_images));

    return array(
        'unused_images' => $all_images,
        'total_attachments' => $total_attachments,
        'unused_count' => count($unused_images),
        'referenced_count' => count($referenced_images),
        'ghost_count' => count($ghost_images),
        'total_filtered' => count($all_images)
    );
}

// 获取文件的所有引用（支持图片、视频、音频、文档等）
function zic_get_image_references($attachment_id, $attachment_url, $enabled_types)
{
    global $wpdb;
    $all_references = array();

    // 获取文件类型
    $file_extension = strtolower(pathinfo($attachment_url, PATHINFO_EXTENSION));
    $mime_type = get_post_mime_type($attachment_id);

    zic_log("开始检测文件引用 - ID: $attachment_id, URL: $attachment_url, 类型: $file_extension");

    // 方法1：通过附件ID直接搜索WordPress的标签（支持图片、视频、音频等）
    $post_types_escaped = array_map(function ($t) use ($wpdb) {
        return "'" . esc_sql($t) . "'";
    }, $enabled_types);
    $in_types = implode(',', $post_types_escaped);

    // 搜索各种WordPress媒体标签格式
    $search_patterns = array(
        'wp-image-' . $attachment_id,     // 图片
        'wp-video-' . $attachment_id,      // 视频
        'wp-audio-' . $attachment_id,      // 音频
        'wp-att-' . $attachment_id,        // 通用附件
    );

    foreach ($search_patterns as $pattern) {
        $wp_media_sql = $wpdb->prepare(
            "SELECT ID, post_title, post_type, post_status FROM $wpdb->posts 
            WHERE post_type IN ($in_types) 
            AND post_status IN ('publish','draft','pending','future') 
            AND post_content LIKE %s",
            '%' . $pattern . '%'
        );
        $wp_media_results = $wpdb->get_results($wp_media_sql);
        if (!empty($wp_media_results)) {
            foreach ($wp_media_results as $ref) {
                // 避免重复添加
                $exists = false;
                foreach ($all_references as $existing_ref) {
                    if ($existing_ref['id'] == $ref->ID) {
                        $exists = true;
                        break;
                    }
                }
                if (!$exists) {
                    $all_references[] = array(
                        'id' => $ref->ID,
                        'title' => $ref->post_title,
                        'type' => $ref->post_type,
                        'status' => $ref->post_status,
                        'usage' => 'content'
                    );
                }
            }
        }
    }

    // 方法2：通过URL搜索（无论之前是否找到引用，都进行URL检测）
    $url_variations = array();
    $url_variations[] = $attachment_url;
    $url_variations[] = basename($attachment_url);

    $upload_dir = wp_upload_dir();
    $relative_url = str_replace($upload_dir['baseurl'], '', $attachment_url);
    $url_variations[] = $relative_url;
    $url_variations[] = ltrim($relative_url, '/');

    // 添加文件名（不含路径）
    $filename = basename($attachment_url);
    $url_variations[] = $filename;

    foreach ($url_variations as $url_var) {
        if (empty($url_var))
            continue;

        $like_img_url = '%' . $wpdb->esc_like($url_var) . '%';
        $content_sql = $wpdb->prepare(
            "SELECT ID, post_title, post_type, post_status FROM $wpdb->posts 
            WHERE post_type IN ($in_types) 
            AND post_status IN ('publish','draft','pending','future') 
            AND post_content LIKE %s",
            $like_img_url
        );
        $results = $wpdb->get_results($content_sql);
        if (!empty($results)) {
            foreach ($results as $ref) {
                // 避免重复添加
                $exists = false;
                foreach ($all_references as $existing_ref) {
                    if ($existing_ref['id'] == $ref->ID) {
                        $exists = true;
                        break;
                    }
                }
                if (!$exists) {
                    $all_references[] = array(
                        'id' => $ref->ID,
                        'title' => $ref->post_title,
                        'type' => $ref->post_type,
                        'status' => $ref->post_status,
                        'usage' => 'content'
                    );
                }
            }
        }
    }

    // 方法3：搜索attachment_id参数（用于WordPress下载按钮等）
    $attachment_id_sql = $wpdb->prepare(
        "SELECT ID, post_title, post_type, post_status FROM $wpdb->posts 
        WHERE post_type IN ($in_types) 
        AND post_status IN ('publish','draft','pending','future') 
        AND post_content LIKE %s",
        '%attachment_id=' . $attachment_id . '%'
    );
    $attachment_id_results = $wpdb->get_results($attachment_id_sql);
    if (!empty($attachment_id_results)) {
        foreach ($attachment_id_results as $ref) {
            // 避免重复添加
            $exists = false;
            foreach ($all_references as $existing_ref) {
                if ($existing_ref['id'] == $ref->ID) {
                    $exists = true;
                    break;
                }
            }
            if (!$exists) {
                $all_references[] = array(
                    'id' => $ref->ID,
                    'title' => $ref->post_title,
                    'type' => $ref->post_type,
                    'status' => $ref->post_status,
                    'usage' => 'content'
                );
            }
        }
    }

    // 方法4：搜索下载链接格式（例如：href="文件URL"）
    $download_patterns = array(
        'href="' . $attachment_url . '"',
        'href=\'' . $attachment_url . '\'',
        'download="' . $filename . '"',
    );

    foreach ($download_patterns as $pattern) {
        $download_sql = $wpdb->prepare(
            "SELECT ID, post_title, post_type, post_status FROM $wpdb->posts 
            WHERE post_type IN ($in_types) 
            AND post_status IN ('publish','draft','pending','future') 
            AND post_content LIKE %s",
            '%' . $wpdb->esc_like($pattern) . '%'
        );
        $download_results = $wpdb->get_results($download_sql);
        if (!empty($download_results)) {
            foreach ($download_results as $ref) {
                // 避免重复添加
                $exists = false;
                foreach ($all_references as $existing_ref) {
                    if ($existing_ref['id'] == $ref->ID) {
                        $exists = true;
                        break;
                    }
                }
                if (!$exists) {
                    $all_references[] = array(
                        'id' => $ref->ID,
                        'title' => $ref->post_title,
                        'type' => $ref->post_type,
                        'status' => $ref->post_status,
                        'usage' => 'content'
                    );
                }
            }
        }
    }

    // 检查是否被设置为特色图片
    $featured_sql = $wpdb->prepare(
        "SELECT p.ID, p.post_title, p.post_type, p.post_status 
        FROM $wpdb->postmeta pm 
        JOIN $wpdb->posts p ON pm.post_id = p.ID 
        WHERE pm.meta_key = '_thumbnail_id' 
        AND pm.meta_value = %d",
        $attachment_id
    );

    $featured_references = $wpdb->get_results($featured_sql);
    if (!empty($featured_references)) {
        foreach ($featured_references as $ref) {
            $all_references[] = array(
                'id' => $ref->ID,
                'title' => $ref->post_title,
                'type' => $ref->post_type,
                'status' => $ref->post_status,
                'usage' => 'featured'
            );
        }
    }

    // 方法5：检查 post meta（自定义字段）中的引用
    // 这个方法可以检测子比主题的付费下载、ACF字段等存储在postmeta中的文件引用
    foreach ($url_variations as $url_var) {
        if (empty($url_var))
            continue;

        $like_meta_url = '%' . $wpdb->esc_like($url_var) . '%';
        $meta_sql = $wpdb->prepare(
            "SELECT p.ID, p.post_title, p.post_type, p.post_status, pm.meta_key
            FROM $wpdb->postmeta pm
            JOIN $wpdb->posts p ON pm.post_id = p.ID
            WHERE p.post_type IN ($in_types)
            AND p.post_status IN ('publish','draft','pending','future')
            AND pm.meta_value LIKE %s",
            $like_meta_url
        );
        $meta_results = $wpdb->get_results($meta_sql);
        if (!empty($meta_results)) {
            foreach ($meta_results as $ref) {
                // 避免重复添加
                $exists = false;
                foreach ($all_references as $existing_ref) {
                    if ($existing_ref['id'] == $ref->ID) {
                        $exists = true;
                        break;
                    }
                }
                if (!$exists) {
                    $all_references[] = array(
                        'id' => $ref->ID,
                        'title' => $ref->post_title,
                        'type' => $ref->post_type,
                        'status' => $ref->post_status,
                        'usage' => 'meta_field',
                        'meta_key' => $ref->meta_key
                    );
                    zic_log("在自定义字段中发现引用 - 文章ID: {$ref->ID}, 字段: {$ref->meta_key}");
                }
            }
        }
    }

    // 方法6：检查用户meta（用户自定义字段）中的引用
    // 这个方法可以检测用户封面图片、用户头像等存储在usermeta中的文件引用

    zic_log("开始检测用户meta - 附件ID: {$attachment_id}, URL: {$attachment_url}");

    // 6.1 通过URL检测（封面、背景等直接存储URL的情况）
    foreach ($url_variations as $url_var) {
        if (empty($url_var))
            continue;

        $like_user_meta_url = '%' . $wpdb->esc_like($url_var) . '%';
        $user_meta_sql = $wpdb->prepare(
            "SELECT u.ID, u.display_name, u.user_login, um.meta_key
            FROM $wpdb->usermeta um
            JOIN $wpdb->users u ON um.user_id = u.ID
            WHERE um.meta_value LIKE %s",
            $like_user_meta_url
        );
        $user_meta_results = $wpdb->get_results($user_meta_sql);
        if (!empty($user_meta_results)) {
            foreach ($user_meta_results as $ref) {
                // 避免重复添加
                $exists = false;
                foreach ($all_references as $existing_ref) {
                    if (isset($existing_ref['user_id']) && $existing_ref['user_id'] == $ref->ID) {
                        $exists = true;
                        break;
                    }
                }
                if (!$exists) {
                    $all_references[] = array(
                        'id' => 'user-' . $ref->ID,
                        'user_id' => $ref->ID,
                        'title' => $ref->display_name . ' (' . $ref->user_login . ')',
                        'type' => 'user',
                        'status' => 'active',
                        'usage' => 'user_meta',
                        'meta_key' => $ref->meta_key
                    );
                    zic_log("在用户自定义字段中发现引用（URL） - 用户ID: {$ref->ID}, 字段: {$ref->meta_key}");
                }
            }
        }
    }

    // 6.2 通过附件ID检测（头像等存储附件ID的情况）
    // 检测常见的头像相关meta_key
    $avatar_meta_keys = array(
        'wp_user_avatar',           // Simple Local Avatars插件
        'simple_local_avatar',      // 另一种头像插件
        'avatar',                   // 通用头像字段
        'user_avatar',              // 用户头像
        'custom_avatar',            // 自定义头像
        'profile_picture',          // 个人资料图片
        'user_cover',               // 用户封面
        'cover_image',              // 封面图片
        'banner_image',             // 横幅图片
    );

    foreach ($avatar_meta_keys as $meta_key) {
        $user_avatar_sql = $wpdb->prepare(
            "SELECT u.ID, u.display_name, u.user_login, um.meta_key, um.meta_value
            FROM $wpdb->usermeta um
            JOIN $wpdb->users u ON um.user_id = u.ID
            WHERE um.meta_key = %s
            AND um.meta_value = %d",
            $meta_key,
            $attachment_id
        );
        $user_avatar_results = $wpdb->get_results($user_avatar_sql);

        if (!empty($user_avatar_results)) {
            foreach ($user_avatar_results as $ref) {
                // 避免重复添加
                $exists = false;
                foreach ($all_references as $existing_ref) {
                    if (isset($existing_ref['user_id']) && $existing_ref['user_id'] == $ref->ID) {
                        $exists = true;
                        break;
                    }
                }
                if (!$exists) {
                    $all_references[] = array(
                        'id' => 'user-' . $ref->ID,
                        'user_id' => $ref->ID,
                        'title' => $ref->display_name . ' (' . $ref->user_login . ')',
                        'type' => 'user',
                        'status' => 'active',
                        'usage' => 'user_meta',
                        'meta_key' => $ref->meta_key
                    );
                    zic_log("在用户自定义字段中发现引用（附件ID） - 用户ID: {$ref->ID}, 字段: {$ref->meta_key}, 附件ID: {$attachment_id}");
                }
            }
        }
    }

    // 6.3 检查所有meta_value为当前附件ID的记录（通用检测 - 同时检测整数和字符串）
    // 排除WordPress系统字段，避免误报
    $excluded_meta_keys = array(
        'wp_capabilities',              // 用户权限
        'wp_user_level',                // 用户等级
        'session_tokens',               // 登录令牌
        'wp_metronet_image_id',         // Metronet插件
        'wp_persisted_preferences',     // 用户界面偏好设置（JSON格式）
        'wp_user-settings',             // 用户设置
        'wp_user-settings-time',        // 用户设置时间戳
        'wp_dashboard_quick_press_last_post_id',  // 快速发布最后文章ID
        'community-events-location',    // 社区活动位置
        'dismissed_wp_pointers',        // 已关闭的提示指针
    );

    $excluded_keys_sql = "'" . implode("','", array_map('esc_sql', $excluded_meta_keys)) . "'";

    $user_meta_id_sql = $wpdb->prepare(
        "SELECT u.ID, u.display_name, u.user_login, um.meta_key, um.meta_value
        FROM $wpdb->usermeta um
        JOIN $wpdb->users u ON um.user_id = u.ID
        WHERE (um.meta_value = %d OR um.meta_value = %s)
        AND um.meta_key NOT IN ({$excluded_keys_sql})",
        $attachment_id,
        (string) $attachment_id
    );
    $user_meta_id_results = $wpdb->get_results($user_meta_id_sql);

    zic_log("通用ID检测查询结果数量: " . count($user_meta_id_results) . " (已排除WordPress系统字段)");

    if (!empty($user_meta_id_results)) {
        foreach ($user_meta_id_results as $ref) {
            zic_log("找到可能的引用 - 用户ID: {$ref->ID}, 字段: {$ref->meta_key}, 值: {$ref->meta_value}");

            // 检查是否为系统字段（额外保护层）
            if (in_array($ref->meta_key, $excluded_meta_keys)) {
                zic_log("跳过系统字段: {$ref->meta_key}");
                continue;
            }

            // 避免重复添加
            $exists = false;
            foreach ($all_references as $existing_ref) {
                if (
                    isset($existing_ref['user_id']) && $existing_ref['user_id'] == $ref->ID &&
                    isset($existing_ref['meta_key']) && $existing_ref['meta_key'] == $ref->meta_key
                ) {
                    $exists = true;
                    break;
                }
            }
            if (!$exists) {
                $all_references[] = array(
                    'id' => 'user-' . $ref->ID . '-' . $ref->meta_key,
                    'user_id' => $ref->ID,
                    'title' => $ref->display_name . ' (' . $ref->user_login . ')',
                    'type' => 'user',
                    'status' => 'active',
                    'usage' => 'user_meta',
                    'meta_key' => $ref->meta_key
                );
                zic_log("在用户自定义字段中发现引用（通用ID检测） - 用户ID: {$ref->ID}, 字段: {$ref->meta_key}, 附件ID: {$attachment_id}");
            }
        }
    }

    // 6.4 检查序列化数据中的引用
    $serialized_sql = "SELECT u.ID, u.display_name, u.user_login, um.meta_key, um.meta_value
        FROM $wpdb->usermeta um
        JOIN $wpdb->users u ON um.user_id = u.ID
        WHERE um.meta_value LIKE 'a:%'
        AND um.meta_value LIKE '%" . $wpdb->esc_like((string) $attachment_id) . "%'
        AND um.meta_key NOT IN ({$excluded_keys_sql})";

    $serialized_results = $wpdb->get_results($serialized_sql);

    if (!empty($serialized_results)) {
        zic_log("发现序列化数据中可能包含引用，数量: " . count($serialized_results));

        foreach ($serialized_results as $ref) {
            // 尝试反序列化检查
            $unserialized = @maybe_unserialize($ref->meta_value);
            $contains_id = false;

            // 检查反序列化后的数据中是否包含附件ID
            if (is_array($unserialized)) {
                array_walk_recursive($unserialized, function ($value) use ($attachment_id, &$contains_id) {
                    if ($value == $attachment_id || $value == (string) $attachment_id) {
                        $contains_id = true;
                    }
                });
            } elseif ($unserialized == $attachment_id) {
                $contains_id = true;
            }

            if ($contains_id) {
                // 避免重复添加
                $exists = false;
                foreach ($all_references as $existing_ref) {
                    if (
                        isset($existing_ref['user_id']) && $existing_ref['user_id'] == $ref->ID &&
                        isset($existing_ref['meta_key']) && $existing_ref['meta_key'] == $ref->meta_key
                    ) {
                        $exists = true;
                        break;
                    }
                }
                if (!$exists) {
                    $all_references[] = array(
                        'id' => 'user-' . $ref->ID . '-' . $ref->meta_key,
                        'user_id' => $ref->ID,
                        'title' => $ref->display_name . ' (' . $ref->user_login . ')',
                        'type' => 'user',
                        'status' => 'active',
                        'usage' => 'user_meta',
                        'meta_key' => $ref->meta_key
                    );
                    zic_log("在用户序列化数据中发现引用 - 用户ID: {$ref->ID}, 字段: {$ref->meta_key}, 附件ID: {$attachment_id}");
                }
            }
        }
    }

    zic_log("文件引用检测完成 - ID: $attachment_id, 找到 " . count($all_references) . " 个引用");

    return $all_references;
}

// 批量删除未使用的图片
function zic_delete_unused_images($image_ids)
{
    $deleted_count = 0;
    $failed_count = 0;
    $results = array();

    foreach ($image_ids as $image_id) {
        $image_id = intval($image_id);
        if ($image_id <= 0) {
            continue;
        }

        $success = zic_force_delete_attachment($image_id);
        if ($success) {
            $deleted_count++;
            $results[] = array(
                'id' => $image_id,
                'status' => 'success',
                'message' => '成功删除'
            );
        } else {
            $failed_count++;
            $results[] = array(
                'id' => $image_id,
                'status' => 'failed',
                'message' => '删除失败'
            );
        }
    }

    return array(
        'deleted_count' => $deleted_count,
        'failed_count' => $failed_count,
        'results' => $results
    );
}

// 处理AJAX请求
add_action('wp_ajax_zic_scan_images', function () {
    check_ajax_referer('zic_scan_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_die('权限不足');
    }

    // 获取筛选参数
    $filters = array();

    if (isset($_POST['show_ghost_images'])) {
        $filters['show_ghost_images'] = $_POST['show_ghost_images'] === 'true';
    }

    if (isset($_POST['show_unused_images'])) {
        $filters['show_unused_images'] = $_POST['show_unused_images'] === 'true';
    }

    if (isset($_POST['show_referenced_images'])) {
        $filters['show_referenced_images'] = $_POST['show_referenced_images'] === 'true';
    }

    if (isset($_POST['min_file_size']) && $_POST['min_file_size'] > 0) {
        $filters['min_file_size'] = intval($_POST['min_file_size']);
    }

    if (isset($_POST['max_file_size']) && $_POST['max_file_size'] > 0) {
        $filters['max_file_size'] = intval($_POST['max_file_size']);
    }

    if (isset($_POST['date_from']) && !empty($_POST['date_from'])) {
        $filters['date_from'] = sanitize_text_field($_POST['date_from']);
    }

    if (isset($_POST['date_to']) && !empty($_POST['date_to'])) {
        $filters['date_to'] = sanitize_text_field($_POST['date_to']);
    }

    if (isset($_POST['file_types']) && is_array($_POST['file_types'])) {
        $filters['file_types'] = array_map('sanitize_text_field', $_POST['file_types']);
    }

    zic_log("接收到的筛选参数: " . json_encode($filters));

    $scan_result = zic_scan_unused_images($filters);
    wp_send_json_success($scan_result);
});

add_action('wp_ajax_zic_delete_images', function () {
    check_ajax_referer('zic_delete_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_die('权限不足');
    }

    $image_ids = isset($_POST['image_ids']) ? array_map('intval', $_POST['image_ids']) : array();
    if (empty($image_ids)) {
        wp_send_json_error('未选择要删除的图片');
    }

    zic_log("开始批量删除图片，数量: " . count($image_ids) . "，ID列表: " . json_encode($image_ids));

    $delete_result = zic_delete_unused_images($image_ids);
    wp_send_json_success($delete_result);
});

